<?php

return [
    "cancel" => "Hủy",
    "confirm" => "Chấp nhận",
    "topic" => [
    	"delete"=>[
        	"title" => "Xóa đề tài",
        	"body" => "Bạn có chắc muốn xóa đề tài này?"
    	]
    ],
    "essay" => [
    	"delete"=>[
        	"title" => "Xóa bài thi",
        	"body" => "Bạn có chắc muốn xóa bài thi này?"
    	]
    ]
];
